# -*- coding: utf-8 -*-
#------------------------------------------------------------
# copyright by Nebelkind / 
#------------------------------------------------------------


import os
import sys
import plugintools
import xbmc,xbmcaddon

Addon=xbmcaddon.Addon('plugin.video.nebelkindmusic')
addonID = 'plugin.video.nebelkindmusic'
addon = sys.argv[0]


local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PLRbAgAjyBgD_g1-IIlaXUcjtdj11CIizl"
YOUTUBE_CHANNEL_ID2 = "PL3oW2tjiIxvSPjTj_NCxrW5QtBPvIAbCg"
YOUTUBE_CHANNEL_ID3 = "PLjzeyhEA84sS6ogo2mXWdcTrL2HRfJUv8"
YOUTUBE_CHANNEL_ID4 = "PLZ6k8u-wUAXrGbyfmJERlnIc8frGKJRlt"
YOUTUBE_CHANNEL_ID5 = "PLfTpobcybLSNuC14ZMzi8aDceCRPTppal"
YOUTUBE_CHANNEL_ID5a = "PL09eGQfW13QhaQTz8guvp0x03_3OoOCdP"
YOUTUBE_CHANNEL_ID5b = "UCUJHYmJ3_1Kwfs3lqYc_Rxg"
YOUTUBE_CHANNEL_ID6 = "PLr_NZxN-rZatAlsQzPXjWtlD1FzJXaMY9"
YOUTUBE_CHANNEL_ID7 = "PL6Go6XFhidEAH6LrK-RKxR5xwhdZ0g4vm"
YOUTUBE_CHANNEL_ID8 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"
YOUTUBE_CHANNEL_ID9 = "PLKsiRyayPqRL5sVgd7zL6s24Vbk7yjqS4"
YOUTUBE_CHANNEL_ID10 = "PLtGLER-XkJgYE-k5gxETU663HeWnORGw1"
YOUTUBE_CHANNEL_ID11 = "PL4aSZKm23GKZdRcr1MX6iBD-eil5TmQvd"
YOUTUBE_CHANNEL_ID12 = "PL3oW2tjiIxvQWubWyTI8PF80gV6Kpk6Rr"
YOUTUBE_CHANNEL_ID12a = "PL42VaKa05JDZ8X3EE5ZS5jDDLSwgIzUgW"
YOUTUBE_CHANNEL_ID12b = "PLs-kfwmk-th7qSMbgpg3Fq6XQQsgFA02b"
YOUTUBE_CHANNEL_ID13 = "UCPKT_csvP72boVX0XrMtagQ/videos"
YOUTUBE_CHANNEL_ID14 = "/UCUknBTWMDCzSggZ_-AgQAbA"
YOUTUBE_CHANNEL_ID15 = "PL21_DgyQIEJ2m30HP_4ChFsPLroRGmfx9"
YOUTUBE_CHANNEL_ID16 = "PLReWWDR05E6tyX6fBRR-0KzRGlBQB8Gvf"
YOUTUBE_CHANNEL_ID17 = "UUdXETutLndnLf5-DOuZz8ZA"
YOUTUBE_CHANNEL_ID18 = "UCT4bwOkXfaIiP0Ey_8Fsd9A"
YOUTUBE_CHANNEL_ID19 = "PLD054C3FEEDF2A3E4"
YOUTUBE_CHANNEL_ID20 = "PLXd6pgsETjgsn5RFu0LVEzIPUft2z4YaR"
YOUTUBE_CHANNEL_ID21 = "PLImmaOPbiVxrpWGBhQvmUma-Chkv4Y02v"
YOUTUBE_CHANNEL_ID22 = "PLImmaOPbiVxqkg_p4jhem4L7r6hUy-EZ-"
YOUTUBE_CHANNEL_ID23 = "PLZwMgILApDwtOay_hMVDuU2j7_kYGImas"
YOUTUBE_CHANNEL_ID24 = "VEVO"
YOUTUBE_CHANNEL_ID25 = "PLvFYFNbi-IBFeP5ALr50hoOmKiYRMvzUq"
YOUTUBE_CHANNEL_ID26 = "PLirAqAtl_h2pRAtj2DgTa3uWIZ3-0LKTA"
YOUTUBE_CHANNEL_ID27 = "TheWeekndVEVO"
YOUTUBE_CHANNEL_ID28 = "PL3oW2tjiIxvQ60uIjLdo7vrUe4ukSpbKl"
YOUTUBE_CHANNEL_ID29 = "PLD59F30B914AD6B1C"
YOUTUBE_CHANNEL_ID30 = "PLn8zSx25Q9jn_OM8ofI2Yvz9TcDo7BRY7"
YOUTUBE_CHANNEL_ID31 = "UCEMFO_EL-5uJrOnDyCA88dw"
YOUTUBE_CHANNEL_ID32 = "PLJtGgr2nbdeNEZsDtjEHBcpHEO3NfBhdj"
YOUTUBE_CHANNEL_ID33 = "PLRZlMhcYkA2EQSwaeOeZnJ1nOfpZTsMuS"
YOUTUBE_CHANNEL_ID34 = "PLMmqTuUsDkRKlyfBfYUnYrkj1imKn77LM"
YOUTUBE_CHANNEL_ID35 = "PL8ug01H2Jv0MSf2ZP7llnOE4xa1onJzvQ"
def run():
    plugintools.log("Musik.run")
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()


def main_list(params):
    plugintools.log("Musik.main_list "+repr(params))
   
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Charts----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )


    plugintools.add_item( 
 
        title=" [COLOR gold]-->[/COLOR][B][COLOR skyblue]Charts[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Charts.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Charts.jpg",
        folder=True )


    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]German Top 100[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/German_100.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/German_100.jpg",
        folder=True )

    
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Charts Mix live set[/COLOR][/B]",
        url="plugin://plugin.video.youtube/channel/UCUknBTWMDCzSggZ_-AgQAbA/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/charts.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/charts.jpg",
        folder=True )	
	
		
   
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Hip Hop and Black----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )

		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Hip Hop Charts[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/hip_hop.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/hip_hop.jpg",
        folder=True )

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Hip Hop und R&B Songs[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID33+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/mix.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/mix.jpg",
        folder=True )
		
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Schlager----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )		
		

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Party Schlager[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Partyschlager.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Partyschlager.jpg",
        folder=True )

		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Schlager Charts[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID6+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/SchlagerCharts.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/SchlagerCharts.jpg",
        folder=True )
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Best of[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5a+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/best of s.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/best of s.jpg",
        folder=True )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Ich find Schlager toll![/COLOR][/B]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID5b+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/schlagertoll.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/schlagertoll.jpg",
        folder=True )				
				
		
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Rock----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Rock[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Rock.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Rock.jpg",
        folder=True )		


    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Rock am Ring[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12a+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/ring.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/ring.jpg",
        folder=True )		
		

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Deutsch Rock[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12b+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/dr.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/dr.jpg",
        folder=True )				
		
		
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Dance/Pop----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )		
		

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Dance[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID7+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Dance.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Dance.jpg",
        folder=True )
	
	
	
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Pop[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID8+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/pop.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/pop.jpg",
        folder=True )	

		
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Electro----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )		
	
	
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Wild Dance[/COLOR][/B]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID28+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/dj.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/dj.jpg",
        folder=True )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Deep House[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/deep_house.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/deep_house.jpg",
        folder=True )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Electro[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID9+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Electro.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Electro.jpg",
        folder=True )		
		
	
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]House[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID10+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/house.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/house.jpg",
        folder=True )
	

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Minimal[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID11+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Minimal.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Minimal.jpg",
        folder=True )	
		
		
    plugintools.add_item( 
 
		title=" [COLOR gold]-->[B][COLOR skyblue]EMH Music[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID19+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/EMH Music.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/EMH Music.jpg",
        folder=True )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Minimal Group[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID20+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Minimal Group.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Minimal Group.jpg",
        folder=True )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]DJ MAG[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID21+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/DJ MAG.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/DJ MAG.jpg",
        folder=True )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Minimal Flash Music[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID22+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/Minimal Flash Music.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/Minimal Flash Music.jpg",
        folder=True )			

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]TOP 100 Minimal Songs 2018[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID34+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/minimaltop.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/minimaltop.jpg",
        folder=True )		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]DJ Swat Music[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID23+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/dj.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/dj.jpg",
        folder=True )			


    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Minimal DJ Live Set[/COLOR][/B]",
        url="plugin://plugin.video.youtube/channel/UCPKT_csvP72boVX0XrMtagQ/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/dj.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/dj.jpg",
        folder=True )
		

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Goa[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID29+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/goa.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/goa.jpg",
        folder=True )		
			

    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Techno 2018 Mix Hands Up [/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID35+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/handsup.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/handsup.jpg",
        folder=True )
		
		
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Vevo----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )		
		
		
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Vevo[/COLOR][/B]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID24+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/vevo.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/vevo.jpg",
        folder=True )

	
   
    plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]New R&B Videos on Vevo![/COLOR][/B]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID27+"/",
		thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/New R&B Videos on Vevo!.jpg",
        fanart="special://home/addons/plugin.video. nebelkindmusic/data/New R&B Videos on Vevo!.jpg",
       folder=True )
	
run()
