# -*- coding: utf-8 -*-
#------------------------------------------------------------
# copyright by Nebelkind / 
#------------------------------------------------------------


import os
import sys
import plugintools
import xbmc,xbmcaddon

Addon=xbmcaddon.Addon('plugin.video.nebelkindmusic')
addonID = 'plugin.video.nebelkindmusic'
addon = sys.argv[0]


local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PLzILaUwmEbemJ2wgUv2R7lqPQb_moUReP"
YOUTUBE_CHANNEL_ID2 = "UCl_9IhxirmXggWtxzszTgyw"
YOUTUBE_CHANNEL_ID3 = "PLjzeyhEA84sS6ogo2mXWdcTrL2HRfJUv8"
YOUTUBE_CHANNEL_ID4 = "PLZ6k8u-wUAXrGbyfmJERlnIc8frGKJRlt"
YOUTUBE_CHANNEL_ID5 = "PLfTpobcybLSNuC14ZMzi8aDceCRPTppal"
YOUTUBE_CHANNEL_ID5a = "PL09eGQfW13QhaQTz8guvp0x03_3OoOCdP"
YOUTUBE_CHANNEL_ID5b = "UCUJHYmJ3_1Kwfs3lqYc_Rxg"
YOUTUBE_CHANNEL_ID6 = "PLr_NZxN-rZatAlsQzPXjWtlD1FzJXaMY9"
YOUTUBE_CHANNEL_ID7 = "PL6Go6XFhidEAH6LrK-RKxR5xwhdZ0g4vm"
YOUTUBE_CHANNEL_ID8 = "PL4o29bINVT4EG_y-k5jGoOu3-Am8Nvi10"
YOUTUBE_CHANNEL_ID9 = "PLKsiRyayPqRL5sVgd7zL6s24Vbk7yjqS4"
YOUTUBE_CHANNEL_ID10 = "PLToQGg12V725ccu7cfjFY1tsOYGeqHyV8"
YOUTUBE_CHANNEL_ID11 = "PL4aSZKm23GKZdRcr1MX6iBD-eil5TmQvd"
YOUTUBE_CHANNEL_ID12 = "PL3oW2tjiIxvQWubWyTI8PF80gV6Kpk6Rr"
YOUTUBE_CHANNEL_ID12a = "PL42VaKa05JDZ8X3EE5ZS5jDDLSwgIzUgW"
YOUTUBE_CHANNEL_ID12b = "PLs-kfwmk-th7qSMbgpg3Fq6XQQsgFA02b"
YOUTUBE_CHANNEL_ID13 = "UCPKT_csvP72boVX0XrMtagQ/videos"
YOUTUBE_CHANNEL_ID14 = "/UCUknBTWMDCzSggZ_-AgQAbA"
YOUTUBE_CHANNEL_ID15 = "PL21_DgyQIEJ2m30HP_4ChFsPLroRGmfx9"
YOUTUBE_CHANNEL_ID16 = "PLReWWDR05E6tyX6fBRR-0KzRGlBQB8Gvf"
YOUTUBE_CHANNEL_ID17 = "UUdXETutLndnLf5-DOuZz8ZA"
YOUTUBE_CHANNEL_ID18 = "UCT4bwOkXfaIiP0Ey_8Fsd9A"
YOUTUBE_CHANNEL_ID19 = "PLD054C3FEEDF2A3E4"
YOUTUBE_CHANNEL_ID20 = "PLXd6pgsETjgsn5RFu0LVEzIPUft2z4YaR"
YOUTUBE_CHANNEL_ID21 = "PLImmaOPbiVxrpWGBhQvmUma-Chkv4Y02v"
YOUTUBE_CHANNEL_ID22 = "PLImmaOPbiVxqkg_p4jhem4L7r6hUy-EZ-"
YOUTUBE_CHANNEL_ID23 = "PLZwMgILApDwtOay_hMVDuU2j7_kYGImas"
YOUTUBE_CHANNEL_ID24 = "VEVO"
YOUTUBE_CHANNEL_ID25 = "PLvFYFNbi-IBFeP5ALr50hoOmKiYRMvzUq"
YOUTUBE_CHANNEL_ID26 = "PLirAqAtl_h2pRAtj2DgTa3uWIZ3-0LKTA"
YOUTUBE_CHANNEL_ID27 = "PL3oW2tjiIxvSPjTj_NCxrW5QtBPvIAbCg"
YOUTUBE_CHANNEL_ID28 = "PLRbAgAjyBgD_g1-IIlaXUcjtdj11CIizl"
YOUTUBE_CHANNEL_ID29 = "PLD59F30B914AD6B1C"
YOUTUBE_CHANNEL_ID30 = "PLn8zSx25Q9jn_OM8ofI2Yvz9TcDo7BRY7"
YOUTUBE_CHANNEL_ID31 = "UCEMFO_EL-5uJrOnDyCA88dw"
YOUTUBE_CHANNEL_ID32 = "PLJtGgr2nbdeNEZsDtjEHBcpHEO3NfBhdj"
YOUTUBE_CHANNEL_ID33 = "PLRZlMhcYkA2EQSwaeOeZnJ1nOfpZTsMuS"
YOUTUBE_CHANNEL_ID34 = "PLMmqTuUsDkRKlyfBfYUnYrkj1imKn77LM"
YOUTUBE_CHANNEL_ID35 = "PL8ug01H2Jv0MSf2ZP7llnOE4xa1onJzvQ"
def run():
    plugintools.log("Musik.run")
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()


def main_list(params):
    plugintools.log("Musik.main_list "+repr(params))
   
    plugintools.add_item( 
        title=" [B][COLOR gold]----------Wild Dance----------[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/icon.png",
        fanart="special://home/addons/plugin.video.nebelkindmusic/fanart.jpg",
        folder=False )

plugintools.add_item( 
 
        title=" [COLOR gold]-->[/COLOR][B][COLOR skyblue]Nebelkind Wild Dance[/COLOR][/B]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/ring.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/ring.jpg",
        folder=True )

plugintools.add_item( 
 
        title=" [COLOR gold]-->[B][COLOR skyblue]Nebelkind Playlists[/COLOR][/B]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="special://home/addons/plugin.video.nebelkindmusic/data/German_100.jpg",
        fanart="special://home/addons/plugin.video.nebelkindmusic/data/German_100.jpg",
        folder=True )





run()
