import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib.request, urllib.error, urllib.parse
import re
import sys
import os
import time
import socket
import io
import gzip

module_log_enabled = False
http_debug_log_enabled = False

LIST = "list"
THUMBNAIL = "thumbnail"
MOVIES = "movies"
TV_SHOWS = "tvshows"
SEASONS = "seasons"
EPISODES = "episodes"
OTHER = "other"

ALL_VIEW_CODES = {
    'list': {
        'skin.confluence': 50,
        'skin.aeon.nox': 509,
        'skin.droid': 50,
        'skin.quartz': 50,
        'skin.re-touched': 50,
    },
    'thumbnail': {
        'skin.confluence': 500,
        'skin.aeon.nox': 509,
        'skin.droid': 51,
        'skin.quartz': 51,
        'skin.re-touched': 500,
    },
    'movies': {
        'skin.confluence': 500,
        'skin.aeon.nox': 509,
        'skin.droid': 51,
        'skin.quartz': 52,
        'skin.re-touched': 500,
    },
    'tvshows': {
        'skin.confluence': 500,
        'skin.aeon.nox': 500,
        'skin.droid': 51,
        'skin.quartz': 52,
        'skin.re-touched': 500,
    },
    'seasons': {
        'skin.confluence': 50,
        'skin.aeon.nox': 509,
        'skin.droid': 50,
        'skin.quartz': 52,
        'skin.re-touched': 50,
    },
    'episodes': {
        'skin.confluence': 504,
        'skin.aeon.nox': 518,
        'skin.droid': 50,
        'skin.quartz': 52,
        'skin.re-touched': 550,
    },
}

def log(message):
    xbmc.log(message)

def _log(message):
    if module_log_enabled:
        xbmc.log("plugintools." + message)

def get_params():
    _log("get_params")

    param_string = sys.argv[2]

    _log("get_params " + str(param_string))

    commands = {}

    if param_string:
        split_commands = param_string[param_string.find('?') + 1:].split('&')

        for command in split_commands:
            _log("get_params command=" + str(command))
            if len(command) > 0:
                if "=" in command:
                    split_command = command.split('=')
                    key = split_command[0]
                    value = urllib.parse.unquote_plus(split_command[1])
                    commands[key] = value
                else:
                    commands[command] = ""

    _log("get_params " + repr(commands))
    return commands

def read(url):
    _log("read " + url)

    with urllib.request.urlopen(url) as f:
        data = f.read()

    return data

def read_body_and_headers(url, post=None, headers=[], follow_redirects=False, timeout=None):
    _log("read_body_and_headers " + url)

    if post is not None:
        _log("read_body_and_headers post=" + post)

    if len(headers) == 0:
        headers.append(["User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0"])

    ficherocookies = os.path.join(get_data_path(), 'cookies.dat')
    _log("read_body_and_headers cookies_file=" + ficherocookies)

    cj = None
    cookielib = None

    try:
        _log("read_body_and_headers importing http.cookiejar")
        import http.cookiejar as cookielib
    except ImportError:
        _log("read_body_and_headers http.cookiejar not available")
        cj = None

    if cj is not None:
        _log("read_body_and_headers Cookies enabled")
        if os.path.isfile(ficherocookies):
            _log("read_body_and_headers Reading cookie file")
            try:
                cj.load(ficherocookies)
            except:
                _log("read_body_and_headers Wrong cookie file, deleting...")
                os.remove(ficherocookies)

        if cookielib:
            _log("read_body_and_headers opener using urllib.request (http.cookiejar)")
            opener = urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(cj)
            )
            urllib.request.install_opener(opener)

    inicio = time.time()

    txheaders = {}
    if post is None:
        _log("read_body_and_headers GET request")
    else:
        _log("read_body_and_headers POST request")

    _log("read_body_and_headers ---------------------------")
    for header in headers:
        _log("read_body_and_headers header %s=%s" % (str(header[0]), str(header[1])))
        txheaders[header[0]] = header[1]
    _log("read_body_and_headers ---------------------------")

    req = urllib.request.Request(url, data=post.encode('utf-8') if post else None, headers=txheaders)
    if timeout is None:
        with urllib.request.urlopen(req) as handle:
            data = handle.read()
    else:
        try:
            with urllib.request.urlopen(req, timeout=timeout) as handle:
                data = handle.read()
        except Exception as e:
            _log(f"Error during request: {e}")

    cj.save(ficherocookies)

    if 'Content-Encoding' in handle.info() and handle.info()['Content-Encoding'] == 'gzip':
        buf = io.BytesIO(data)
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()

    info = handle.info()
    _log("read_body_and_headers Response")

    returnheaders = []
    _log("read_body_and_headers ---------------------------")
    for header in info:
        _log("read_body_and_headers " + header + "=" + info[header])
        returnheaders.append([header, info[header]])
    _log("read_body_and_headers ---------------------------")

    fin = time.time()
    _log("read_body_and_headers Downloaded in %d seconds " % (fin - inicio + 1))
    _log("read_body_and_headers body=" + str(data))

    return data, returnheaders

class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.parse.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        return infourl
    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302

def find_multiple_matches(text, pattern):
    _log("find_multiple_matches pattern=" + pattern)

    matches = re.findall(pattern, text, re.DOTALL)

    return matches

def find_single_match(text, pattern):
    _log("find_single_match pattern=" + pattern)

    result = ""
    try:
        matches = re.findall(pattern, text, flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""

    return result

def add_item(action="", title="", plot="", url="", thumbnail="", fanart="", show="", episode="", extra="", page="", info_labels=None, isPlayable=False, folder=True):
    _log(f"add_item action=[{action}] title=[{title}] url=[{url}] thumbnail=[{thumbnail}] fanart=[{fanart}] show=[{show}] episode=[{episode}] extra=[{extra}] page=[{page}] isPlayable=[{isPlayable}] folder=[{folder}]")

    listitem = xbmcgui.ListItem(title, path=url)


    if info_labels is None:
        info_labels = {"Title": title, "FileName": title, "Plot": plot}
    listitem.setInfo("video", info_labels)


    if fanart != "":
        listitem.setArt({'fanart': fanart}) 
        xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)  

    if thumbnail != "":
        listitem.setArt({'thumb': thumbnail, 'icon': thumbnail}) 


    if url.startswith("plugin://"):
        itemurl = url
        listitem.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    elif isPlayable:
        listitem.setProperty("Video", "true")
        listitem.setProperty('IsPlayable', 'true')
        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % (
            sys.argv[0], action, urllib.parse.quote_plus(title), urllib.parse.quote_plus(url),
            urllib.parse.quote_plus(thumbnail), urllib.parse.quote_plus(plot),
            urllib.parse.quote_plus(extra), urllib.parse.quote_plus(page))
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    else:
        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % (
            sys.argv[0], action, urllib.parse.quote_plus(title), urllib.parse.quote_plus(url),
            urllib.parse.quote_plus(thumbnail), urllib.parse.quote_plus(plot),
            urllib.parse.quote_plus(extra), urllib.parse.quote_plus(page))
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)




def close_item_list():
    _log("close_item_list")

    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

def play_resolved_url(url):
    _log("play_resolved_url [" + url + "]")

    listitem = xbmcgui.ListItem(path=url)
    listitem.setProperty('IsPlayable', 'true')
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def direct_play(url):
    _log("direct_play [" + url + "]")

    title = ""

    try:

        xlistitem = xbmcgui.ListItem(title, path=url)
    except Exception as e:
        _log(f"Error creating ListItem: {e}")
        xlistitem = xbmcgui.ListItem(title)


    xlistitem.setInfo("video", {"Title": title})


    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playlist.add(url, xlistitem) 

    player_type = xbmc.PLAYER_CORE_AUTO 
    xbmcPlayer = xbmc.Player(player_type)
    xbmcPlayer.play(playlist)


def direct_play1(url):
    _log("direct_play [" + url + "]")

    title = ""

    try:
        xlistitem = xbmcgui.ListItem(title, path=url)
    except:
        xlistitem = xbmcgui.ListItem(title )
    xlistitem.setInfo("video", {"Title": title})

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playlist.add(url, xlistitem)

    player_type = xbmc.PLAYER_CORE_AUTO
    xbmcPlayer = xbmc.Player(player_type)
    xbmcPlayer.play(playlist)

def show_picture(url):
    local_folder = os.path.join(get_data_path(), "images")
    if not os.path.exists(local_folder):
        try:
            os.mkdir(local_folder)
        except:
            pass
    local_file = os.path.join(local_folder, "temp.jpg")

    urllib.request.urlretrieve(url, local_file)
    xbmc.executebuiltin("SlideShow(" + local_folder + ")")

def get_temp_path():
    _log("get_temp_path")

    dev = xbmc.translatePath("special://temp/")
    _log("get_temp_path ->'" + str(dev) + "'")

    return dev

def get_runtime_path():
    _log("get_runtime_path")

    dev = xbmc.translatePath(__settings__.getAddonInfo('Path'))
    _log("get_runtime_path ->'" + str(dev) + "'")

    return dev

def get_data_path():
    _log("get_data_path")

    dev = xbmc.translatePath(__settings__.getAddonInfo('Profile'))

    if not os.path.exists(dev):
        os.makedirs(dev)

    _log("get_data_path ->'" + str(dev) + "'")

    return dev

def get_setting(name):
    _log("get_setting name='" + name + "'")

    dev = __settings__.getSetting(name)

    _log("get_setting ->'" + str(dev) + "'")

    return dev

def set_setting(name, value):
    _log(f"set_setting name='{name}','{value}'")

    __settings__.setSetting(name, value)

def open_settings_dialog():
    _log("open_settings_dialog")

    __settings__.openSettings()

def get_localized_string(code):
    _log(f"get_localized_string code={code}")

    dev = __language__(code)

    try:
        dev = dev.encode("utf-8")
    except:
        pass

    _log(f"get_localized_string ->'{dev}'")

    return dev

def keyboard_input(default_text="", title="", hidden=False):
    _log(f"keyboard_input default_text='{default_text}'")

    keyboard = xbmc.Keyboard(default_text, title, hidden)
    keyboard.doModal()

    if keyboard.isConfirmed():
        tecleado = keyboard.getText()
    else:
        tecleado = ""

    _log(f"keyboard_input ->'{tecleado}'")

    return tecleado

def message(text1, text2="", text3=""):
    _log(f"message text1='{text1}', text2='{text2}', text3='{text3}'")

    if text3 == "":
        xbmcgui.Dialog().ok(text1, text2)
    elif text2 == "":
        xbmcgui.Dialog().ok("", text1)
    else:
        xbmcgui.Dialog().ok(text1, text2, text3)


def message_yes_no(text1, text2="", text3=""):
    _log("message_yes_no text1='"+text1+"', text2='"+text2+"', text3='"+text3+"'")

    if text3=="":
        yes_pressed = xbmcgui.Dialog().yesno( text1 , text2 )
    elif text2=="":
        yes_pressed = xbmcgui.Dialog().yesno( "" , text1 )
    else:
        yes_pressed = xbmcgui.Dialog().yesno( text1 , text2 , text3 )

    return yes_pressed

def selector(option_list,title="Select one"):
    _log("selector title='"+title+"', options="+repr(option_list))

    dia = xbmcgui.Dialog()
    selection = dia.select(title,option_list)

    return selection

def set_view(view_mode, view_code=0):
    _log("set_view view_mode='"+view_mode+"', view_code="+str(view_code))


    if view_mode==MOVIES:
        _log("set_view content is movies")
        xbmcplugin.setContent( int(sys.argv[1]) ,"movies" )
    elif view_mode==TV_SHOWS:
        _log("set_view content is tvshows")
        xbmcplugin.setContent( int(sys.argv[1]) ,"tvshows" )
    elif view_mode==SEASONS:
        _log("set_view content is seasons")
        xbmcplugin.setContent( int(sys.argv[1]) ,"seasons" )
    elif view_mode==EPISODES:
        _log("set_view content is episodes")
        xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )


    skin_name = xbmc.getSkinDir()
    _log("set_view skin_name='"+skin_name+"'")

    try:
        if view_code==0:
            _log("set_view view mode is "+view_mode)
            view_codes = ALL_VIEW_CODES.get(view_mode)
            view_code = view_codes.get(skin_name)
            _log("set_view view code for "+view_mode+" in "+skin_name+" is "+str(view_code))
            xbmc.executebuiltin("Container.SetViewMode("+str(view_code)+")")
        else:
            _log("set_view view code forced to "+str(view_code))
            xbmc.executebuiltin("Container.SetViewMode("+str(view_code)+")")
    except:
        _log("Unable to find view code for view mode "+str(view_mode)+" and skin "+skin_name)

f = open( os.path.join( os.path.dirname(__file__) , "addon.xml") )
data = f.read()
f.close()

addon_id = find_single_match(data,'id="([^"]+)"')
if addon_id=="":
    addon_id = find_single_match(data,"id='([^']+)'")

__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString
