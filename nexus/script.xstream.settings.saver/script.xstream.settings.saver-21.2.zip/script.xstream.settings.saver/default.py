import xbmc
import os
import xbmcaddon
import xbmcgui
import xbmc
import threading
import io
import xbmcvfs

__addon__ = xbmcaddon.Addon()
addon = xbmcaddon.Addon
addon_id = 'script.xstream.settings.saver'
addonInfo = xbmcaddon.Addon().getAddonInfo
setting = xbmcaddon.Addon().getSetting
dialog = xbmcgui.Dialog()
setSetting = xbmcaddon.Addon().setSetting
execute = xbmc.executebuiltin


WINDOW_HOME = xbmcgui.Window(10000)


def getPlatformName():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'win32'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    else:
        return 'unknown'


def openSettings(query=None, id=addonInfo('id')):
    try:
        execute('Addon.OpenSettings(%s)' % id)
        dialog.ok('xStream Einstellungen','Lege zuerst den Speicherort deiner xStream Einstellungen fest.','Weiter mit OK.','Anschliessend Addon neu starten')
        xbmc.sleep(3000)
    except:
        pass

def openSettings1(query=None, id=addonInfo('id')):
    try:
        execute('Addon.OpenSettings(%s)' % id)
        dialog.ok('xStream Einstellungen','Bitte gebe den Wiederherstellungspfad deiner xStream Einstellungen an.','Weiter mit OK.','Anschliessend Addon neu starten')
        xbmc.sleep(3000)
    except:
        pass



def main():

        favourites = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.xstream/settings.xml')
        platform = getPlatformName()
        dialog = xbmcgui.Dialog()
        entries = ["xStream Einstellungen sichern", "xStream Einstellungen wiederherstellen", None]

        nr = xbmcgui.Dialog().select("xStream Einstellungen", entries)
        entry = entries[nr]

        if entry == 'xStream Einstellungen sichern':
            if setting('speicher_pfad') == '':
                openSettings('0.0')
            else:
                Path = xbmcvfs.translatePath(__addon__.getSetting('speicher_pfad'))
                if getPlatformName() == 'win32':
                    if not Path.endswith('\\'):
                        Path += '\\'
                else:
                    if not Path.endswith('/'):
                        Path += '/'
                FullPath = Path + 'settings.bak'
                if os.path.exists(favourites):
                    with io.open(favourites, 'r', encoding= "utf-8") as h:
                        reading = h.read().encode('ascii', 'ignore').decode('ascii')
                        with open(FullPath, 'w') as g:
                            g.write(reading)
                    dialog.ok('xStream Einstellungen','xStream Einstellungen erfolgreich gespeichert')
                else:
                    dialog.ok('xStream Einstellungen','Du hast keine xStream Einstellungen angelegt')

        if entry == 'xStream Einstellungen wiederherstellen':
            Path = xbmcvfs.translatePath(__addon__.getSetting('speicher_pfad'))
            if getPlatformName() == 'win32':
                if not Path.endswith('\\'):
                    Path += '\\'
            else:
                if not Path.endswith('/'):
                    Path += '/'
            FullPath = Path + 'settings.bak'
            FullPathR = xbmcvfs.translatePath(FullPath)
            if os.path.exists(FullPathR):
                with io.open(FullPathR, 'r') as h:
                    reading = h.read()
                with open(favourites, 'w') as g:
                    g.write(reading)
                dialog.ok('xStream Einstellungen','xStream Einstellungen erfolgreich wiederhergestellt...\nKODi muss neu gestartet werden.....')
            else:
                if setting('re_pfad') == '':
                    openSettings1('0.2')
                else:
                    Path = xbmcvfs.translatePath(__addon__.getSetting('re_pfad'))
                    with io.open(Path, 'r') as h:
                        reading = h.read()
                        with open(favourites, 'w') as g:
                            g.write(reading)
                    dialog.ok('xStream Einstellungen','xStream Einstellungen erfolgreich wiederhergestellt...\nKODi muss neu gestartet werden.....')




if __name__ == '__main__':
    main()