"""Module for auth"""
from __future__ import absolute_import, division, unicode_literals
import os, re, uuid, sys
import json


from urllib.parse import urlencode, urljoin
from urllib.request import urlopen, Request


#import urllib.parse, urllib.request, urllib.error
#from urllib.parse import urlparse
import dataclasses
import requests
from .globals import G
from .utils import Logger
import xbmcgui
from lib import api

key = None
mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
params = {
    'type' : 'stb',
    'action' : 'handshake',
    'JsHttpRequest' : '1-xml'
    }
load = '/portal.php'
timezone = 'Europe%2FBerlin'
user_agent = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3'
def is_json(json_string):
    try:
        json.loads(json_string)
        return True
    except ValueError:
        return False



@dataclasses.dataclass
class Token:
    """Token"""
    value: str = None


class Auth:
    TOKEN_FILE = 'token.json'
    def __init__(self):
        self._token_path = G.addon_config.token_path
        self._token = Token()
        self._load_cache()
    def get_token(self, retries=3):
        """Get Token"""
        try:

            if self._token.value:
                return self._token.value
            _url = G.portal_config.portal_base_url
            load_url = urljoin(_url, load)
            _mac_cookie = G.portal_config.mac_cookie
            _portal_url = G.portal_config.portal_url

            headers = {
                'User-Agent' : user_agent,
                'Cookie' : _mac_cookie + '; stb_lang=en; timezone=' + timezone,
                'Referer' : load_url,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet'
                        }
            if key is not None:
                headers.update('Authorization', 'Bearer ' + key)


            data = urlencode(params).encode('utf-8')
            req = Request(load_url, data, headers)
            resp = urlopen(req).read().decode("utf-8")
            if not is_json(resp):
                req = Request(load_url + '?' + data.decode('utf-8'), headers=headers)
                resp = urlopen(req).read().decode("utf-8")
            if not is_json(resp):
                raise Exception(resp)
            info = json.loads(resp)
            token = info['js']['token']
            self._token.value = token
            self._save_cache()
            #api.getProfile(_url)
            #epg = api.get_epg_data()
            return self._token.value
        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            Logger.log(f'Traceback:: {failure}')
            Logger.log(f'Exception raised. Error = {e}')


    def clear_cache(self):
        """Clear token from cache"""
        self._token = Token()
        if os.path.exists(os.path.join(self._token_path, self.TOKEN_FILE)):
            os.remove(os.path.join(self._token_path, self.TOKEN_FILE))

    def _load_cache(self):
        """ Load tokens from cache """
        try:
            with open(os.path.join(self._token_path, self.TOKEN_FILE), 'r') as f_desc:
                self._token.__dict__ = json.loads(f_desc.read())
        except (IOError, TypeError, ValueError):
            Logger.warn('We could not use the cache since it is invalid or non-existent.')

    def _save_cache(self):
        """ Store tokens in cache """
        if not os.path.exists(self._token_path):
            os.makedirs(self._token_path)

        with open(os.path.join(self._token_path, self.TOKEN_FILE), 'w') as f_desc:
            json.dump(self._token.__dict__, f_desc, indent=2)