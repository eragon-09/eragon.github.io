# Kodi-plugin.video.titan.playlistloader
Taking ownership of plugin.video.titan.playlistloader previously owned by Avigdork
See: 
