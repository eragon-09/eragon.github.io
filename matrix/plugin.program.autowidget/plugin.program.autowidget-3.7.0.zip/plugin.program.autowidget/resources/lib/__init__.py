"""All Python scripts for AutoWidget go here."""
