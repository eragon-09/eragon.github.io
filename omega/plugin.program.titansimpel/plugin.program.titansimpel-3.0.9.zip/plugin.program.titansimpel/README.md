# plugin.program.simplewizard
Simple Wizard for Kodi

![Wizard-logo](https://raw.githubusercontent.com/eragon-09/eragon-09.github.io/refs/heads/main/matrix/plugin.program.titansimpel/resources/icon.png)

* [Eragon Repository](https://eragon-09.github.io)